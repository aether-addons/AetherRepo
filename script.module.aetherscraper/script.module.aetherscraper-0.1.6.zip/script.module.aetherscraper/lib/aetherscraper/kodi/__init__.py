"""Kodi integration helpers."""
